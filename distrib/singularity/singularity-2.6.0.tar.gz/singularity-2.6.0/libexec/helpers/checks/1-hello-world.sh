#!/bin/bash

echo "Hello World, security level 1"
exit 0
